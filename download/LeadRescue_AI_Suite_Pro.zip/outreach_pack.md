# Pack de Prospección y Conversión B2B (Outreach de Alta Conversión)

**Target:** Fundadores, Directores de Crecimiento y Socios Directores de Agencias de Marketing B2B (5-20 empleados).  
**Estrategia:** *Value-First "Lead Leak Audit"* (Auditoría de fuga de prospectos sin fricción).  
**Ticket de Oferta:** $750 USD (50% upfront / 50% milestone).

---

## 1. Secuencia de Frío Multicanal (Email & LinkedIn)

### Email 1: El Test de Fricción (Día 0)
**Asunto:** {{company}}: ¿cuántos minutos tardan en responder un lead de {{service_in_form}}?  
*(Variante de Asunto B: auditoría rápida de tiempo de respuesta en {{company}})*

> Hola {{first_name}},
> 
> Hice una prueba rápida en el formulario de contacto de {{company}} hace un momento.
> 
> Si un prospecto calificado entra a las 7:30 PM un jueves buscando {{service_in_form}}, lo normal en el 90% de las agencias es que reciba un correo estándar de "Gracias por escribirnos" o que nadie le responda hasta la mañana siguiente.
> 
> Según los datos de *InsideSales*, la probabilidad de agendar esa llamada cae un **391%** si no hay contacto calificado en los primeros 60 segundos.
> 
> Diseñamos un motor con IA en la nube que lee el formulario en tiempo real, filtra el spam, calcula el presupuesto y le envía a tu closer una alerta por Telegram con el borrador de respuesta listo para enviar en menos de 45 segundos.
> 
> Grabé un video de 90 segundos mostrando cómo funcionaría exactamente conectado a su formulario actual de {{form_type, ej: Typeform/Elementor}}.
> 
> ¿Te molesta si te comparto el enlace por aquí?
> 
> Un saludo,  
> **[Tu Nombre]**  
> Especialista en Speed-to-Lead & Automatización RevOps

---

### Email 2: Seguimiento con Demo en Video (Día 3)
**Asunto:** Re: {{company}}: ¿cuántos minutos tardan en responder un lead de {{service_in_form}}?

> Hola {{first_name}},
> 
> Sé que estás enfocado en la entrega de clientes y cierres de mes, así que fui directo al grano.
> 
> Te grabé el video aquí: **[Enlace a Video Loom Personalizado - 1m 50s]**
> 
> En el video muestro:
> 1. Qué ocurre cuando un cliente con presupuesto de +$3,000/mes llena el formulario de {{company}}.
> 2. Cómo la IA califica la urgencia y redacta el email personalizado sin intervención humana en 30 segundos.
> 3. Cómo lo implementamos en 48 horas sin tocar su infraestructura actual ni pagar suscripciones de software adicionales.
> 
> Si te hace sentido implementarlo con una garantía de reembolso total a 14 días, ¿tienes 10 minutos este jueves para ver cómo conectarlo?
> 
> **[Tu Nombre]**

---

### Email 3: El Breakup Email con Cálculo Financiero (Día 6)
**Asunto:** ¿Cerramos el expediente de {{company}}?

> Hola {{first_name}},
> 
> Asumo que en este momento optimizar el tiempo de respuesta de los prospectos de {{company}} no es una prioridad en la agenda.
> 
> Solo te dejo este último número:
> Si captan 30 leads al mes y solo 2 de ellos se enfrían por tardar más de 2 horas en contactarlos, a un ticket promedio de $1,500/mes eso representa **$36,000 USD al año** que se van a agencias de la competencia que responden primero.
> 
> Nuestro sistema se implementa por una tarifa única de $750 USD (con garantía de devolución del 100% si no califica el 100% de sus leads en menos de 60 segundos).
> 
> Si más adelante deciden tapar esa fuga, seguimos en contacto.
> 
> Éxitos con el cierre de trimestre,
> 
> **[Tu Nombre]**

---

## 2. Guion Palabra por Palabra para Video Loom (2 Minutos)

**Configuración Previa del Grabador:**
- Pantalla dividida: a la izquierda, la página de contacto de la agencia del cliente (`agencia.com/contacto`); a la derecha, la pantalla de Telegram o Google Sheets recibiendo los leads de prueba.
- Duración estricta: entre 1:45 y 2:10 minutos.

```text
[0:00 - 0:20] GANCHO VISUAL ESPECÍFICO
"Hola [Nombre], qué tal. Estoy aquí en la web de [Nombre de su Agencia], específicamente en su formulario de [Contacto/Auditoría]. 
La razón por la que te grabo este video de menos de dos minutos es porque sé que cada lead B2B que entra por aquí les cuesta tiempo, dinero en tráfico o esfuerzo de marca."

[0:20 - 0:50] DEMOSTRACIÓN DEL DOLOR (THE LATENCY LEAK)
"El gran problema que sufren agencias de su tamaño es que si entra un cliente un viernes por la tarde o a las 8 de la noche pidiendo ayuda con [Servicio que ofrecen], 
el lead se enfría. Para cuando el closer abre el CRM el lunes por la mañana, ese tomador de decisión ya habló con otras dos agencias. 
Además, su equipo pierde horas revisando formularios que resultan ser spam o personas pidiendo empleo."

[0:50 - 1:30] DEMOSTRACIÓN EN VIVO DE LA SOLUCIÓN
"Mira lo que hicimos. Diseñamos un motor con inteligencia artificial que se conecta a este mismo formulario sin cambiar de hosting ni pagar herramientas caras.
Voy a simular un lead en tiempo real: pongo 'Director de Operaciones, presupuesto 4,000 dólares, necesito escalar pauta este mes'.
Le doy enviar... y fíjate en mi pantalla derecha:
En exactamente 3 segundos, la IA analizó la urgencia, le asignó un Score de 94/100, detectó que es un cliente caliente y te mandó esta alerta a Telegram con el botón directo a su WhatsApp y un borrador de respuesta profesional hiper-personalizado citando su problema exacto."

[1:30 - 2:00] OFERTA CON REVERSIÓN TOTAL DE RIESGO & CTA
"Instalamos toda esta arquitectura lista para producción en su agencia en menos de 48 horas.
El costo de implementación es de una tarifa única de $750 dólares, dividida en dos pagos: 50% al iniciar y 50% una vez que lo veas funcionando en vivo.
Y con una garantía categórica: si en 14 días no califica y enruta el 100% de tus prospectos en menos de 60 segundos, te devuelvo el 100% de tu dinero de inmediato.
Si te interesa ver cómo se vería en tu agencia esta misma semana, responde a este correo o haz clic en el enlace de abajo y lo revisamos en 10 minutos. Un saludo."
```

---

## 3. Matriz de Manejo de Objeciones en Llamada de Venta

| Objeción del Prospecto | Causa Real / Inseguridad | Respuesta Táctica Palabra por Palabra |
| :--- | :--- | :--- |
| **"Ya tenemos HubSpot / Zapier / Make."** | Cree que esto es redundante o que su equipo interno puede hacerlo. | *"Totalmente comprensible, y de hecho nuestro sistema se integra directo con tu HubSpot. La diferencia es que Zapier solo mueve datos; no analiza la intención, no calcula el presupuesto ni te redacta la respuesta en 30 segundos. Nosotros no te vendemos otro software, sino la capa de inteligencia ya programada y lista en 48 horas sin distraer a tu equipo técnico."* |
| **"Nuestros comerciales ya responden rápido."** | Sobrestima la velocidad real de su equipo, especialmente en noches o fines de semana. | *"Es genial que tengan esa disciplina comercial. Una pregunta rápida: cuando un lead entra un viernes a las 8:30 PM o un domingo por la tarde, ¿en cuántos minutos le responde tu equipo con una propuesta a medida? El 78% de los cierres se van con la primera agencia que contesta de forma inteligente. Nuestro motor cubre exactamente esos huecos ciegos 24/7."* |
| **"No tenemos presupuesto en este trimestre."** | Percibe el servicio como un costo o gasto, no como un multiplicador de ingresos. | *"Te entiendo perfectamente. Sin embargo, no estamos hablando de un gasto publicitario. Si este sistema te ayuda a rescatar un solo cliente de $1,500/mes que de otro modo se hubiera ido a la competencia por tardanza, el sistema se paga dos veces en los primeros 30 días. Además, no requiere pagos mensuales recurrentes de nuestra parte."* |
| **"Mándame la propuesta por email y lo evaluamos."** | Desea terminar la llamada por cortesía; objeción de aplazamiento. | *"Con gusto te la envío al terminar la llamada. Pero como la implementación toma solo 48 horas y está respaldada por una garantía de devolución completa del 100%, la única pregunta real es: ¿tienen capacidad para absorber 2 o 3 llamadas de venta extra este mes? Si la respuesta es sí, iniciamos con el 50% hoy y el viernes lo tienen en vivo."* |
| **"¿Qué pasa si la IA se equivoca o inventa información?"** | Miedo a que la IA envíe mensajes absurdos o comprometa la reputación de la agencia. | *"Excelente punto. Por eso nuestro flujo está configurado con temperatura 0.1 (modo analítico estricto) y en la primera fase el sistema funciona en modo co-piloto: la alerta te llega a Telegram con la respuesta ya redactada y un botón de 'Aprobar y Enviar'. Tu equipo mantiene el control total con 1 solo clic."* |
| **"¿Por qué cobran solo $750 USD si dicen que vale tanto?"** | Desconfianza por precio bajo; teme que sea una solución de baja calidad. | *"Cobramos $750 de setup porque nuestra arquitectura está estandarizada y la desplegamos en 48 horas con costos de infraestructura en cero. Nuestro verdadero negocio es que cuando veas el resultado en tu agencia, nos contrates para implementarlo en los clientes de tu agencia bajo un modelo de reparto o setup recurrente."* |

---

## 4. Mensajes de Prospección Rápida en LinkedIn (Social Selling)

### Mensaje de Conexión (Sin Enlaces, Cero Fricción)
> *"Hola {{first_name}}, vi que en {{company}} están escalando el área de {{specialty}}. Quería hacerte una pregunta sobre cómo manejan actualmente el speed-to-lead en su formulario web cuando entran solicitudes fuera de horario. Un saludo cordial."*

### Mensaje Post-Aceptación (24h después)
> *"Gracias por conectar, {{first_name}}. Te comento directo: grabé un video de 90 segundos mostrando cómo conectar un calificador con IA a su formulario que analiza el presupuesto y envía alerta con el borrador de email listo a WhatsApp en 30 segundos. ¿Te parece si te comparto el video por aquí?"*
