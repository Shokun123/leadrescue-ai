/**
 * ============================================================================
 * LEAD ENGINE B2B - MOTOR DE CALIFICACIÓN Y ENRUTAMIENTO INSTANTÁNEO CON IA
 * ============================================================================
 * Arquitectura: 100% Gratuita (Google Apps Script + Google AI Studio Free Tier)
 * Costo de Servidor: $0 USD / mes
 * Tiempo de Respuesta Promedio: < 2.5 segundos
 * 
 * Capacidades:
 * 1. Webhook Endpoint seguro (doPost) para recibir leads de cualquier formulario
 *    (Elementor, Typeform, Tally, Webflow, WordPress, React, HTML nativo).
 * 2. Inferencia con Google Gemini 1.5 Flash en modo JSON Estructurado.
 * 3. Almacenamiento automático y formateado en Google Sheets.
 * 4. Alerta prioritaria inmediata a Telegram (Bot API).
 * 5. Notificación ejecutiva por Email en HTML responsive con llamada a la acción.
 * 6. Registro de auditoría (logs) y tolerancia a fallos.
 * ============================================================================
 */

// CONFIGURACIÓN GLOBAL (Guardar preferentemente en Project Settings -> Script Properties)
const CONFIG = {
  GEMINI_API_KEY: PropertiesService.getScriptProperties().getProperty('GEMINI_API_KEY') || 'TU_GEMINI_API_KEY_AQUI',
  GEMINI_MODEL: 'gemini-1.5-flash',
  GEMINI_API_VERSION: 'v1beta',
  TELEGRAM_BOT_TOKEN: PropertiesService.getScriptProperties().getProperty('TELEGRAM_BOT_TOKEN') || '',
  TELEGRAM_CHAT_ID: PropertiesService.getScriptProperties().getProperty('TELEGRAM_CHAT_ID') || '',
  NOTIFY_EMAIL: PropertiesService.getScriptProperties().getProperty('NOTIFY_EMAIL') || Session.getActiveUser().getEmail(),
  MIN_HOT_SCORE: 70, // Leads con score >= 70 disparan alerta crítica
  SHEET_NAME_LEADS: 'Leads_Calificados',
  SHEET_NAME_LOGS: 'Logs_Auditoria'
};

/**
 * Endpoint HTTP POST: Recibe el payload del formulario web
 */
function doPost(e) {
  const startTime = new Date().getTime();
  let responsePayload = { success: false, message: '', lead_id: null };

  try {
    if (!e || (!e.postData && !e.parameter)) {
      throw new Error('Payload vacío o inválido.');
    }

    // 1. Extraer y sanitizar datos de entrada
    let rawLead = {};
    if (e.postData && e.postData.contents) {
      try {
        rawLead = JSON.parse(e.postData.contents);
      } catch (err) {
        // Fallback a URL encoded si no es JSON puro
        rawLead = e.parameter || {};
      }
    } else {
      rawLead = e.parameter || {};
    }

    const leadData = normalizeLeadInput(rawLead);
    const leadId = Utilities.getUuid().substring(0, 8);
    leadData.id = leadId;
    leadData.timestamp = new Date().toISOString();

    // 2. Ejecutar análisis y calificación cognitiva con Gemini IA
    const aiEvaluation = evaluateLeadWithGemini(leadData);

    // 3. Persistir en Google Sheets
    persistLeadToSheet(leadData, aiEvaluation);

    // 4. Notificaciones multicanal
    sendNotificationEmail(leadData, aiEvaluation);
    if (CONFIG.TELEGRAM_BOT_TOKEN && CONFIG.TELEGRAM_CHAT_ID) {
      sendTelegramAlert(leadData, aiEvaluation);
    }

    const durationMs = new Date().getTime() - startTime;
    logAudit('INFO', `Lead procesado exitosamente: ${leadData.email} en ${durationMs}ms`, leadId);

    responsePayload = {
      success: true,
      lead_id: leadId,
      score: aiEvaluation.score,
      qualification: aiEvaluation.qualification_status,
      execution_time_ms: durationMs
    };

    return ContentService.createTextOutput(JSON.stringify(responsePayload))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (error) {
    const errorMsg = error.toString();
    logAudit('ERROR', `Fallo en procesamiento de lead: ${errorMsg}`);
    
    responsePayload = {
      success: false,
      error: errorMsg
    };

    return ContentService.createTextOutput(JSON.stringify(responsePayload))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

/**
 * Normaliza los campos comunes de diferentes constructores de formularios
 */
function normalizeLeadInput(raw) {
  return {
    name: raw.name || raw.nombre || raw.fullName || raw.first_name || 'Desconocido',
    email: raw.email || raw.correo || raw['e-mail'] || '',
    phone: raw.phone || raw.telefono || raw.tel || raw.whatsapp || 'No suministrado',
    company: raw.company || raw.empresa || raw.business || 'Independiente / No indicada',
    website: raw.website || raw.sitio_web || raw.url || 'No suministrado',
    service_interest: raw.service || raw.servicio || raw.interest || raw.subject || 'General',
    budget_declared: raw.budget || raw.presupuesto || 'No declarado',
    message: raw.message || raw.mensaje || raw.comments || raw.description || ''
  };
}

/**
 * Llama a la API de Google Gemini 1.5 Flash con salida JSON estructurada garantizada
 */
function evaluateLeadWithGemini(lead) {
  const endpoint = `https://generativelanguage.googleapis.com/${CONFIG.GEMINI_API_VERSION}/models/${CONFIG.GEMINI_MODEL}:generateContent?key=${CONFIG.GEMINI_API_KEY}`;

  const promptContent = `
Actúa como el Director Comercial y Auditor Senior de Calificación B2B de una Agencia de Marketing Digital.
Evalúa rigurosamente el siguiente lead entrante para clasificar su potencial de cierre, capacidad de pago y urgencia:

--- DATOS DEL PROSPECTO ---
Nombre: ${lead.name}
Email: ${lead.email}
Teléfono: ${lead.phone}
Empresa / Negocio: ${lead.company}
Sitio Web: ${lead.website}
Servicio de Interés: ${lead.service_interest}
Presupuesto Declarado: ${lead.budget_declared}
Mensaje / Desafío: ${lead.message}
----------------------------

Criterios de Evaluación:
1. Puntuación (score: 0 a 100): Calidad del lead basada en si es un tomador de decisión, claridad del dolor y viabilidad de servicio.
2. Estado de Calificación (qualification_status): "HOT" (urgencia alta + capacidad aparente), "WARM" (interés real pero falta validar detalles), "COLD" (muy vago o bajo encaje), "DISQUALIFIED" (spam, búsqueda de empleo, venta de servicios hacia nosotros).
3. Nivel de Urgencia (urgency_level): "CRITICA_24H", "ALTA_SEMANA", "EXPLORATORIA", "NULA".
4. Presupuesto Estimado (budget_estimation): { "min_usd": number, "max_usd": number, "tier": "PREMIUM_OVER_5K" | "STANDARD_1K_5K" | "LOW_UNDER_1K" | "INDETERMINADO" }.
5. Dolores Clave (key_pain_points): lista de los problemas reales que el lead busca resolver.
6. Red Flags (red_flags): alertas de riesgo (ej: pide trabajo gratis, presupuesto irrisorio, mensaje genérico de bot).
7. Siguiente Acción Recomendada (next_best_action): "LLAMAR_INMEDIATO", "ENVIAR_WHATSAPP_PRIORITARIO", "SECUENCIA_NURTURING", "DESCARTAR".
8. Resumen Comercial para el Closer (sales_brief): 2 bullets concisos con el ángulo de venta exacto a usar en la llamada.
9. Borrador de Respuesta Personalizada (personalized_draft_reply): Redacta un email ultra-profesional, empático, sin relleno comercial, que valide su dolor y proponga una llamada breve de 15 minutos.
`;

  const requestPayload = {
    contents: [
      {
        role: "user",
        parts: [{ text: promptContent }]
      }
    ],
    generationConfig: {
      temperature: 0.1,
      responseMimeType: "application/json"
    }
  };

  const options = {
    method: 'post',
    contentType: 'application/json',
    payload: JSON.stringify(requestPayload),
    muteHttpExceptions: true
  };

  const response = UrlFetchApp.fetch(endpoint, options);
  const responseCode = response.getResponseCode();
  const responseText = response.getContentText();

  if (responseCode !== 200) {
    throw new Error(`Gemini API Error [Status ${responseCode}]: ${responseText}`);
  }

  const jsonResponse = JSON.parse(responseText);
  const rawAiText = jsonResponse.candidates[0].content.parts[0].text;
  
  return JSON.parse(rawAiText);
}

/**
 * Guarda el registro en Google Sheets garantizando estructura y encabezados
 */
function persistLeadToSheet(lead, ai) {
  const ss = SpreadsheetApp.getActiveSpreadsheet() || SpreadsheetApp.create('B2B_Lead_Engine_Database');
  let sheet = ss.getSheetByName(CONFIG.SHEET_NAME_LEADS);

  if (!sheet) {
    sheet = ss.insertSheet(CONFIG.SHEET_NAME_LEADS);
    const headers = [
      'ID Lead', 'Fecha / Hora', 'Nombre', 'Email', 'Teléfono', 'Empresa', 
      'Web', 'Score (0-100)', 'Estado', 'Urgencia', 'Rango Presupuesto ($)', 
      'Próxima Acción', 'Dolores Detectados', 'Borrador Respuesta', 'Mensaje Original'
    ];
    sheet.appendRow(headers);
    sheet.getRange(1, 1, 1, headers.length).setFontWeight('bold').setBackground('#1e293b').setFontColor('#ffffff');
    sheet.setFrozenRows(1);
  }

  const budgetStr = ai.budget_estimation ? `$${ai.budget_estimation.min_usd || 0} - $${ai.budget_estimation.max_usd || 0} (${ai.budget_estimation.tier})` : 'N/A';
  const painPointsStr = Array.isArray(ai.key_pain_points) ? ai.key_pain_points.join(' | ') : '';

  sheet.appendRow([
    lead.id,
    new Date(),
    lead.name,
    lead.email,
    lead.phone,
    lead.company,
    lead.website,
    ai.score,
    ai.qualification_status,
    ai.urgency_level,
    budgetStr,
    ai.next_best_action,
    painPointsStr,
    ai.personalized_draft_reply || '',
    lead.message
  ]);
}

/**
 * Envía una notificación ejecutiva en HTML responsive al email del equipo comercial
 */
function sendNotificationEmail(lead, ai) {
  const isHot = (ai.score >= CONFIG.MIN_HOT_SCORE);
  const badgeColor = isHot ? '#dc2626' : (ai.score >= 50 ? '#d97706' : '#6b7280');
  const subjectPrefix = isHot ? '🔥 [LEAD CALIENTE URGENTE]' : '📥 [Nuevo Lead Entrante]';
  const subject = `${subjectPrefix} ${lead.name} (${lead.company}) - Score: ${ai.score}/100`;

  const htmlBody = `
  <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 620px; margin: 0 auto; padding: 20px; background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px;">
    <div style="background-color: #0f172a; padding: 16px 20px; border-radius: 6px 6px 0 0; color: #ffffff;">
      <h2 style="margin: 0; font-size: 18px; font-weight: 600;">Notificación Instantánea de Lead - AI Engine</h2>
      <p style="margin: 4px 0 0 0; font-size: 13px; color: #94a3b8;">Calificado y auditado en tiempo real</p>
    </div>

    <div style="background: #ffffff; padding: 20px; border-radius: 0 0 6px 6px; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
        <span style="background-color: ${badgeColor}; color: white; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: bold; text-transform: uppercase;">
          Score: ${ai.score}/100 (${ai.qualification_status})
        </span>
        <span style="font-size: 13px; color: #64748b; font-weight: 500;">
          Urgencia: <b>${ai.urgency_level}</b>
        </span>
      </div>

      <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px; font-size: 14px;">
        <tr><td style="padding: 8px 0; color: #64748b; width: 35%;">Prospecto:</td><td style="padding: 8px 0; font-weight: 600; color: #1e293b;">${lead.name}</td></tr>
        <tr><td style="padding: 8px 0; color: #64748b;">Empresa / Web:</td><td style="padding: 8px 0; color: #1e293b;"><b>${lead.company}</b> (${lead.website})</td></tr>
        <tr><td style="padding: 8px 0; color: #64748b;">Email:</td><td style="padding: 8px 0;"><a href="mailto:${lead.email}" style="color: #2563eb; text-decoration: none;">${lead.email}</a></td></tr>
        <tr><td style="padding: 8px 0; color: #64748b;">Teléfono / WhatsApp:</td><td style="padding: 8px 0; font-weight: 600;"><a href="https://wa.me/${lead.phone.replace(/[^0-9]/g, '')}" style="color: #16a34a; text-decoration: none;">${lead.phone} (Abrir Chat)</a></td></tr>
        <tr><td style="padding: 8px 0; color: #64748b;">Acción Sugerida:</td><td style="padding: 8px 0; font-weight: bold; color: #dc2626;">${ai.next_best_action}</td></tr>
      </table>

      <div style="background-color: #f1f5f9; padding: 12px 16px; border-radius: 6px; margin-bottom: 18px;">
        <h4 style="margin: 0 0 6px 0; font-size: 13px; color: #334155; text-transform: uppercase; letter-spacing: 0.5px;">Resumen Comercial para la Llamada:</h4>
        <p style="margin: 0; font-size: 13px; color: #475569; line-height: 1.5;">${ai.sales_brief || 'Revisar notas en la base de datos.'}</p>
      </div>

      <div style="border-top: 1px solid #e2e8f0; padding-top: 16px;">
        <h4 style="margin: 0 0 8px 0; font-size: 13px; color: #334155;">Borrador de Respuesta Rápida Sugerida:</h4>
        <div style="background: #fafafa; border: 1px dashed #cbd5e1; padding: 12px; border-radius: 4px; font-size: 13px; color: #334155; white-space: pre-line;">
${ai.personalized_draft_reply || 'Hola ' + lead.name + ', hemos recibido tu solicitud y la estamos revisando.'}
        </div>
      </div>

      <div style="margin-top: 24px; text-align: center;">
        <a href="mailto:${lead.email}?subject=Re:%20Contacto%20${encodeURIComponent(lead.company)}&body=${encodeURIComponent(ai.personalized_draft_reply || '')}" 
           style="background-color: #2563eb; color: #ffffff; padding: 10px 20px; border-radius: 6px; text-decoration: none; font-size: 14px; font-weight: 600; display: inline-block;">
          Responder con 1 Clic
        </a>
      </div>
    </div>
  </div>
  `;

  MailApp.sendEmail({
    to: CONFIG.NOTIFY_EMAIL,
    subject: subject,
    htmlBody: htmlBody
  });
}

/**
 * Envía una alerta compacta por Telegram Bot API para respuesta en < 60 segundos
 */
function sendTelegramAlert(lead, ai) {
  const url = `https://api.telegram.org/bot${CONFIG.TELEGRAM_BOT_TOKEN}/sendMessage`;
  
  const statusEmoji = ai.score >= 70 ? '🔥' : (ai.score >= 50 ? '⚡' : '📋');
  const messageText = `
${statusEmoji} *NUEVO LEAD B2B IDENTIFICADO*
━━━━━━━━━━━━━━━━━━
👤 *Nombre:* ${escapeMarkdown(lead.name)}
🏢 *Empresa:* ${escapeMarkdown(lead.company)}
📊 *Score:* \`${ai.score}/100\` (${ai.qualification_status})
⏱️ *Urgencia:* ${ai.urgency_level}
🎯 *Acción:* \`${ai.next_best_action}\`
📞 *Tel:* [${escapeMarkdown(lead.phone)}](tel:${lead.phone})
📧 *Email:* \`${escapeMarkdown(lead.email)}\`

💡 *Estrategia Closer:*
_${escapeMarkdown(ai.sales_brief || 'Contactar de inmediato.')}_
━━━━━━━━━━━━━━━━━━
`;

  const payload = {
    chat_id: CONFIG.TELEGRAM_CHAT_ID,
    text: messageText,
    parse_mode: 'Markdown',
    disable_web_page_preview: true
  };

  try {
    UrlFetchApp.fetch(url, {
      method: 'post',
      contentType: 'application/json',
      payload: JSON.stringify(payload),
      muteHttpExceptions: true
    });
  } catch (err) {
    logAudit('WARN', `Error enviando alerta a Telegram: ${err.toString()}`);
  }
}

/**
 * Escapa caracteres reservados para Telegram Markdown v1
 */
function escapeMarkdown(text) {
  if (!text) return '';
  return text.toString().replace(/[_*[\]()~`>#+-=|{}.!]/g, '\\$&');
}

/**
 * Registra logs de auditoría en una hoja separada
 */
function logAudit(level, message, leadId) {
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    if (!ss) return;
    let sheet = ss.getSheetByName(CONFIG.SHEET_NAME_LOGS);
    if (!sheet) {
      sheet = ss.insertSheet(CONFIG.SHEET_NAME_LOGS);
      sheet.appendRow(['Timestamp', 'Nivel', 'Lead ID', 'Mensaje']);
      sheet.setFrozenRows(1);
    }
    sheet.appendRow([new Date(), level, leadId || '-', message]);
  } catch (e) {
    Logger.log(`Logging failed: ${e.toString()}`);
  }
}
