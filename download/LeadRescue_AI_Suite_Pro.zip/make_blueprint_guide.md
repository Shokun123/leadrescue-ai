# Guía de Implementación del Blueprint en Make.com (Plan Gratuito $0 USD)

**Objetivo:** Desplegar el sistema de calificación y Speed-to-Lead con IA en **Make.com** aprovechando el plan gratuito (1,000 operaciones/mes) sin pagar un solo dólar de suscripción.

---

## 1. La Matemática del Costo Cero ($0 USD)

El plan gratuito de Make.com otorga **1,000 operaciones por mes**.

### Desglose de Operaciones por Lead Procesado:
1. **Módulo 1: Webhook Trigger:** 1 operación
2. **Módulo 2: HTTP Request a Gemini 1.5 Flash:** 1 operación (la API de Google AI Studio es 100% gratuita hasta 1,500 solicitudes al día).
3. **Módulo 3: JSON Parse:** 1 operación
4. **Módulo 4: Google Sheets (Append Row):** 1 operación
5. **Módulo 5: Telegram Alerta (Solo si Score >= 60):** 1 operación (0 operaciones si el lead es basura/spam).

**Total de operaciones por lead válido:** **4 a 5 operaciones**.  
**Capacidad mensual:** Con 1,000 operaciones, el cliente puede procesar entre **200 y 250 leads calificados al mes** completamente gratis.

> [!TIP]
> Una agencia de marketing mediana con 5-20 empleados recibe un promedio de 40 a 120 leads mensuales en su formulario principal. El consumo mensual será de ~400 operaciones, dejando más del 60% de margen libre.

---

## 2. Diagrama de Flujo del Blueprint

```mermaid
flowchart LR
    A["Formulario Web / Typeform"] -->|"POST Webhook"| B["Módulo 1: Custom Webhook"]
    B -->|"Filtro: Email Válido"| C["Módulo 2: HTTP Gemini Flash"]
    C -->|"JSON Output"| D["Módulo 3: Parse JSON"]
    D --> E["Módulo 4: Google Sheets"]
    D -->|"Filtro: Score >= 60"| F["Módulo 5: Telegram Alerta"]
    D -.->|"Score < 60 (Descalificado)"| G["Fin del Flujo (0 Ops extra)"]
```

---

## 3. Instrucciones de Importación Directa (Paso a Paso)

### Paso 1: Crear el Escenario en Make
1. Entra a tu cuenta gratuita en [Make.com](https://www.make.com).
2. Haz clic en **Create a new scenario**.
3. En la barra inferior de tres puntos (`...`), selecciona **Import Blueprint**.
4. Sube el archivo `make_blueprint.json` ubicado en este mismo directorio.

### Paso 2: Conectar el Webhook de Entrada
1. Haz clic en el Módulo 1 (**Custom Webhook**).
2. Haz clic en **Add** para generar una nueva URL de Webhook.
3. Copia esa URL y pégala en la configuración de webhook de tu formulario (Elementor Pro, Typeform, Tally Forms, Jotform, Gravity Forms o Webflow).
4. Envía un envío de prueba desde tu formulario para que Make detecte la estructura de datos automáticamente.

### Paso 3: Configurar la API Key de Gemini
1. Obtén tu clave gratuita en [Google AI Studio](https://aistudio.google.com/app/apikey).
2. En el Módulo 2 (**HTTP Request**), reemplaza `{{var.gemini_api_key}}` en la URL por tu clave real o define la variable de entorno en Make.
3. Verifica que la cabecera `Content-Type: application/json` esté presente.

### Paso 4: Conectar Google Sheets
1. En el Módulo 4 (**Google Sheets**), haz clic en **Add Connection** e inicia sesión con una cuenta de Google.
2. Crea una hoja de cálculo llamada `Leads_Calificados` con las columnas:
   `Fecha | Nombre | Email | Empresa | Score | Estado | Urgencia | Próxima Acción | Resumen Closer | Borrador Email`
3. Mapea los campos correspondientes desde el Módulo 3 (**Parse JSON**).

### Paso 5: Conectar la Alerta de Telegram
1. En Telegram, abre `@BotFather`, escribe `/newbot` y obtén el **Bot Token**.
2. Envía un mensaje a tu nuevo bot e ingresa a `https://api.telegram.org/bot<TU_BOT_TOKEN>/getUpdates` para obtener tu `chat_id`.
3. En el Módulo 5 (**Telegram**), añade tu conexión con el Bot Token y pega tu `chat_id`.

---

## 4. Reglas de Optimización para Preservar Operaciones

1. **Filtro Anti-Spam Frontal (Entre Módulo 1 y 2):**
   - Condición: `email` debe contener `@` y `name` no debe estar vacío.
   - Si un bot o spammer envía un payload vacío, el flujo se detiene en el Módulo 1 gastando solo 1 operación en lugar de llamar a la IA y a los demás módulos.
2. **Filtro de Alerta Condicional (Entre Módulo 3 y 5):**
   - Solo se envía notificación push de Telegram si `score >= 60`.
   - Los leads fríos o descartados se archivan silenciosamente en Google Sheets sin gastar operaciones de mensajería ni interrumpir al equipo de ventas.

---

## 5. Comparativa Técnica: ¿Google Apps Script o Make.com?

| Criterio | Google Apps Script (`lead_engine.gs`) | Make.com Blueprint (`make_blueprint.json`) |
| :--- | :--- | :--- |
| **Costo Mensual** | **$0 USD (100% Ilimitado en uso típico)** | **$0 USD (hasta 1,000 ops/mes)** |
| **Curva de Adopción Cliente** | Requiere copiar código en Apps Script (10 min). | Interfaz visual drag-and-drop muy fácil de entender. |
| **Mantenimiento** | Cero dependencias externas, corre en Google Cloud. | Requiere mantener activa la cuenta de Make. |
| **Recomendación para la Venta** | Ideal para entregar una solución "llave en mano" invisible y eterna. | Ideal si el cliente ya usa Make/Zapier y quiere ver el diagrama visual. |
