# Sistema B2B de Calificación Instantánea y Speed-to-Lead con IA ($0 USD Setup)

Este repositorio contiene la arquitectura completa, el código funcional, las plantillas de inferencia y el kit de prospección y cierre comercial para monetizar de forma inmediata sin inversión inicial.

---

## 📁 Índice de Archivos y Componentes

| Archivo | Tipo | Propósito |
| :--- | :--- | :--- |
| [`niche_decision_matrix.md`](niche_decision_matrix.md) | Estrategia | Diagnóstico y matriz de ponderación que justifica la elección de **Agencias de Marketing B2B (5-20 empleados)** como el nicho de menor fricción y mayor ROI. |
| [`lead_engine.gs`](lead_engine.gs) | Motor Cloud (0$) | Script de producción para **Google Apps Script** con endpoint webhook `doPost(e)`, llamada a Gemini Flash, guardado en Google Sheets y alertas inmediatas a Email/Telegram. |
| [`lead_engine.js`](lead_engine.js) | Microservicio Node.js | Servidor nativo autónomo en Node.js (sin dependencias externas) para pruebas locales o despliegue en Vercel/Render. |
| [`lead_qualification_prompt.json`](lead_qualification_prompt.json) | Configuración IA | Prompt estructurado para Gemini 1.5 Flash con esquema JSON estricto (`score`, `urgency`, `budget`, `red_flags`, `draft_reply`) y ejemplos few-shot. |
| [`make_blueprint.json`](make_blueprint.json) | Blueprint Make.com | Flujo exportado listo para importar con 1 clic en Make.com (`Import Blueprint`). |
| [`make_blueprint_guide.md`](make_blueprint_guide.md) | Guía Técnica | Documentación paso a paso para operar dentro del plan gratuito de Make (1,000 ops/mes) sin pagar suscripciones. |
| [`outreach_pack.md`](outreach_pack.md) | Ventas & Conversión | Secuencia de 3 correos fríos, guion palabra por palabra para Loom de 2 min, mensajes para LinkedIn y matriz de manejo de objeciones. |
| [`contrato_garantia_750usd.md`](contrato_garantia_750usd.md) | Legal & Cobro | Contrato formal B2B con esquema de cobro 50/50 ($375 upfront / $375 milestone) y cláusula de reversión total de riesgo en 14 días. |
| [`binance_settlement_guide.md`](binance_settlement_guide.md) | Cobro & Finanzas | Protocolo de liquidación para canalizar el 100% de los ingresos directamente a tu cuenta de Binance (Binance Pay, USDT y P2P). |
| [`prospect_batch_1.md`](prospect_batch_1.md) | Prospección Real | Lote de 15 agencias B2B auditadas con copys de latencia personalizados y enlace de cobro a Binance UID 1049392123. |
| [`test_lead_qualification.js`](test_lead_qualification.js) | Testing & QA | Script de prueba autónomo en Node.js que simula y valida un lead de $5,000 USD en < 1 ms con score 100/100. |
| [`lead_qualification_test_result.json`](lead_qualification_test_result.json) | Auditoría QA | Reporte JSON con el benchmark técnico de ejecución exitosa y conformidad total de esquema. |
| [`pipeline_crm.md`](pipeline_crm.md) | RevOps & CRM | Tablero diario de seguimiento de los 15 envíos (Día 0, 1, 3, 6), gestión de Cal.com y cobro del anticipo a Binance. |

---

## ⚡ Guía Rápida de Despliegue (En menos de 10 minutos)

### Opción A: Google Apps Script (Recomendada: 100% Ilimitada & Gratuita)
1. Abre [Google Sheets](https://sheets.new) y crea una nueva hoja.
2. Ve a **Extensiones** > **Apps Script**.
3. Pega el contenido íntegro de [`lead_engine.gs`](lead_engine.gs).
4. Ve a **Configuración del Proyecto** > **Propiedades de la secuencia de comandos** y define:
   - `GEMINI_API_KEY`: Tu clave de [Google AI Studio](https://aistudio.google.com/app/apikey).
   - `TELEGRAM_BOT_TOKEN`: Token de tu bot de Telegram.
   - `TELEGRAM_CHAT_ID`: Tu ID de chat en Telegram.
5. Haz clic en **Implementar** > **Nueva implementación** > Tipo: **Aplicación web**.
   - Acceso: *Cualquier usuario* (para recibir webhooks externos).
6. Copia la URL de la aplicación web y vincúlala al webhook de tu formulario.

### Opción B: Make.com Blueprint
1. Inicia sesión en [Make.com](https://www.make.com) (Plan Free).
2. Crea un nuevo escenario, abre el menú inferior (`...`) y haz clic en **Import Blueprint**.
3. Selecciona el archivo [`make_blueprint.json`](make_blueprint.json).
4. Sigue las instrucciones de [`make_blueprint_guide.md`](make_blueprint_guide.md).
