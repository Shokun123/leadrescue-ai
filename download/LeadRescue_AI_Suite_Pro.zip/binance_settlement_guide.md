# Guía Maestra de Liquidación y Cobro Directo en Binance
**Protocolo para Canalizar el 100% de los Ingresos a tu Cuenta de Binance**

---

## 1. Configuración de tus Datos de Cobro en Binance

Para que los clientes te depositen directamente en tu cuenta de Binance, debes tener a mano tres datos clave de tu aplicación o web de Binance:

### 1.1. Tu Binance Pay ID y Binance UID (Cobro Cero Comisiones)
- **Dónde encontrarlo:** En la App de Binance > Menú superior > Ícono de **Pay** (o en tu perfil > **UID**).
- **Ventaja:** Si el cliente tiene cuenta en Binance, te transfiere en 5 segundos con **0% de comisión**.
- **Formato:** `Binance Pay ID: [Tu Pay ID]` / `Binance UID: [Tu UID]`.

### 1.2. Tu Dirección de Depósito en USDT (Cripto Estable)
- **Dónde encontrarlo:** En Binance > *Depósito* > *Depositar Cripto* > Seleccionar **USDT**.
- **Redes Recomendadas (por velocidad y costo mínimo):**
  1. **BNB Smart Chain (BEP-20):** Comisión de red ~$0.15 USD.
  2. **Polygon (MATIC):** Comisión de red ~$0.05 USD.
  3. **TRON (TRC-20):** Muy popular en negocios internacionales (comisión de red ~$1 - $2 USD).
  > **Nota de Seguridad:** Guarda tu dirección pública de depósito de USDT para cada red. Nunca compartas tus claves privadas ni contraseñas.

---

## 2. Los 3 Métodos de Cobro según el Tipo de Cliente

```mermaid
flowchart TD
    Cliente["Cliente B2B Cerrado ($750 USD)"] --> Tipo{¿Cómo prefiere pagar?}
    Tipo -->|Cripto / Web3 / Binance| R1["Ruta 1: Binance Pay o USDT Directo<br/>(0% comisiones, acreditación en 60s)"]
    Tipo -->|Tarjeta de Crédito/Débito| R2["Ruta 2: Enlace Binance Pay / On-Ramp<br/>(Paga con tarjeta, recibes USDT en Binance)"]
    Tipo -->|Transferencia Bancaria USD/EUR| R3["Ruta 3: Wise / Cuenta Receptora -> Binance<br/>(Transferencia a Binance vía P2P o depósito)"]
    
    R1 --> Binance["Tu Billetera Spot / Fondos de Binance"]
    R2 --> Binance
    R3 --> Binance
    
    Binance --> Earn["Opción A: Generar 5-10% APR en Binance Simple Earn"]
    Binance --> P2P["Opción B: Retirar a tu banco local en minutos vía Binance P2P"]
```

---

### Ruta 1: Cobro Directo Cripto / Binance Pay (Recomendada)
Muchas agencias de marketing y startups operan habitualmente con criptoactivos estables para evitar las trabas bancarias internacionales:
- Les compartes tu **código QR de Binance Pay** o tu **dirección de USDT (TRC-20 / BEP-20 / Polygon)**.
- El cliente transfiere los **$375.00 USD** del anticipo.
- Los fondos impactan inmediatamente en tu billetera de Fondos o Spot de Binance.

---

### Ruta 2: Clientes Tradicionales que Exigen Tarjeta de Crédito (Visa / Mastercard)
Si una empresa cliente solo puede pagar con tarjeta corporativa:
1. **Binance Pay Checkout (Payment Link):**
   - Desde la web de Binance (versión para comerciantes o Pay), puedes generar un enlace de pago con importe fijo ($375 USD).
   - Binance permite al pagador usar diversos métodos, incluyendo tarjetas admitidas.
2. **On-Ramp Directo (MoonPay / Ramp Network / Transak):**
   - Le envías al cliente una solicitud de pago donde el cliente ingresa los datos de su tarjeta corporativa para comprar $375 USD en USDT y los envía directamente a tu dirección de depósito de Binance.
   - El cliente lo ve como un cargo común en su estado de cuenta y tú recibes los USDT directamente en Binance.

---

### Ruta 3: Clientes que Pagan por Transferencia Bancaria Tradicional
Si el cliente requiere hacer una transferencia bancaria (ACH en USA o SEPA en Europa):
1. Recibes la transferencia en una cuenta multidivisa sin costo fijo (ej. Wise, Payoneer o cuenta bancaria internacional).
2. Transfieres los fondos a tu cuenta de Binance mediante depósito bancario admitido o utilizando el mercado **Binance P2P** (compras USDT con el saldo transferido) en menos de 10 minutos.

---

## 3. Plantilla de Solicitud de Cobro / Factura para Enviar al Cliente

Copia y pega este mensaje al cerrar la llamada de venta:

```text
Estimado [Nombre del Cliente],

Un gusto haber conversado hoy. Tal como acordamos en nuestro contrato de servicio, procedemos con el Hito 1 (Anticipo de Inicio: $375.00 USD) para comenzar la implementación inmediata de su sistema de calificación en 72 horas.

Para su comodidad y máxima rapidez sin costos de comisiones bancarias SWIFT, puede completar la liquidación por cualquiera de las siguientes vías directas:

1. BINANCE PAY (Instantáneo, 0% comisiones):
   - Binance UID: **1049392123**
   - O escanee el código QR adjunto a este mensaje.

2. TRANSFERENCIA DIRECTA EN USDT (Criptoactivo Estable 1:1 con el USD):
   - Moneda: USDT
   - Red: BNB Smart Chain (BEP-20) / Polygon / TRON (TRC-20)
   - Dirección de billetera: [INGRESA_AQUÍ_TU_DIRECCIÓN_PÚBLICA_DE_USDT]

3. PAGO CON TARJETA CORPORATIVA (Visa / Mastercard):
   - Enlace seguro de pago: [INGRESA_AQUÍ_TU_ENLACE_DE_PAGO]

Una vez efectuado el envío, favor de responder con el comprobante o captura de pantalla para activar de inmediato el despliegue técnico de su infraestructura.

Atentamente,
[Tu Nombre]
Especialista en Automatización B2B
```

---

## 4. Qué Hacer con los Fondos una vez en Binance

Una vez que los fondos llegan a tu cuenta de Binance:
1. **Generar Interés Pasivo (Binance Simple Earn):**
   - Si no necesitas el dinero de inmediato, suscríbete al producto flexible de USDT en Binance Earn.
   - Genera entre un **5% y un 10% APR anual** en dólares digitales con liquidez inmediata (puedes retirarlo en cualquier segundo).
2. **Retiro a tu Moneda Local (Binance P2P):**
   - Cuando quieras transferir el dinero a tu cuenta bancaria local de tu país:
     1. Ve a la sección **P2P** de Binance.
     2. Selecciona **Vender** > **USDT**.
     3. Elige tu moneda local y tu banco preferido.
     4. Selecciona un comerciante verificado (con más de 98% de órdenes completadas).
     5. Recibes la transferencia bancaria local en tu cuenta en 3 a 5 minutos, confirmas la recepción en la app y se liberan los USDT.
