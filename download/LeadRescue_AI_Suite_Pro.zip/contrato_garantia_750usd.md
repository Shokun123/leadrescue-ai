# CONTRATO DE PRESTACIÓN DE SERVICIOS TECNOLÓGICOS Y GARANTÍA DE RENDIMIENTO

**DOCUMENTO DE ACUERDO PROFESIONAL B2B**  
**REFERENCIA:** SETUP-REV-750-AI  
**VALOR TOTAL DEL CONTRATO:** $750.00 USD  

---

Entre las partes:

**DE UNA PARTE:**  
**EL PROVEEDOR:** [NOMBRE DEL CONSULTOR / AGENCIA PROVEEDORA], actuando como especialista independiente en Arquitectura de Automatización y Sistemas RevOps con Inteligencia Artificial, con correo de contacto: `[EMAIL_PROVEEDOR]`.

**DE OTRA PARTE:**  
**EL CLIENTE:** [NOMBRE DE LA AGENCIA CLIENTE], sociedad legalmente constituida o empresa unipersonal, representada en este acto por [NOMBRE DEL FIRMANTE], en su condición de [CARGO: Fundador / Director / Representante Legal], con correo de contacto corporativo: `[EMAIL_CLIENTE]`.

Ambas partes se reconocen mutuamente capacidad jurídica suficiente para suscribir el presente Contrato de Prestación de Servicios, al tenor de las siguientes:

---

## CLÁUSULAS

### PRIMERA. OBJETO DEL CONTRATO
El PROVEEDOR se compromete a diseñar, integrar, configurar y poner en marcha para el CLIENTE un **"Sistema de Calificación Instantánea y Speed-to-Lead con Inteligencia Artificial"**, diseñado específicamente para procesar de forma automatizada los prospectos comerciales que ingresen a través de los formularios digitales del CLIENTE.

### SEGUNDA. ALCANCE Y ENTREGABLES ESPECÍFICOS
El servicio incluye de manera taxativa los siguientes entregables:
1. **Conexión de Webhook:** Integración técnica directa con el formulario web principal del CLIENTE (WordPress, Elementor, Typeform, Tally, Webflow o CRM existente).
2. **Motor de Calificación Cognitiva:** Conexión y configuración de la API de Google Gemini (modelo 1.5 Flash o superior) con prompt estructurado para extracción de:
   - Score numérico de calidad (0 a 100).
   - Nivel de urgencia de contratación.
   - Estimación y justificación de presupuesto.
   - Detección de señales de advertencia (red flags) y descarte de spam.
   - Resumen comercial estratégico (sales brief) para el equipo de ventas.
   - Borrador de email de respuesta personalizada e hiper-específica.
3. **Base de Datos Centralizada:** Configuración de Google Sheets estructurado con bloqueo de cabeceras, registro histórico y métricas de auditoría.
4. **Sistema de Alerta Prioritaria:** Canal de notificación en tiempo real vía Telegram Bot API o Email HTML corporativo para notificar al equipo comercial en menos de 45 segundos por cada lead calificado con score superior al umbral acordado.
5. **Sesión de Capacitación y Traspaso:** Sesión técnica de 30 minutos vía videollamada para el traspaso de control y explicación de operación al equipo del CLIENTE.

### TERCERA. PLAZO DE ENTREGA
El PROVEEDOR se compromete a entregar el sistema completamente funcional y en fase de pruebas dentro de un plazo máximo de **cuarenta y ocho (48) horas hábiles** contadas a partir de la recepción efectiva de los accesos técnicos requeridos y del pago inicial estipulado en la Cláusula Cuarta.

### CUARTA. HONORARIOS Y MODALIDAD DE PAGO (50% / 50%)
El precio total pactado por la ejecución integral de los entregables es de **SETECIENTOS CINCUENTA DÓLARES AMERICANOS ($750.00 USD)**, libres de retenciones bancarias. El pago se efectuará conforme a los siguientes hitos:

1. **Hito 1 (Anticipo de Inicio):** Pago del **50% ($375.00 USD)** a la firma del presente contrato y previo al inicio de los trabajos de configuración.
2. **Hito 2 (Liquidación contra Resultados):** Pago del **50% restante ($375.00 USD)** a los **catorce (14) días naturales** posteriores a la puesta en producción del sistema, previa verificación de que el motor ha operado conforme a los estándares pactados.

**Métodos de Pago Aceptados y Liquidación:**
- **Binance Pay / Transferencia Interna (Recomendado - 0% comisiones):** Transferencia directa a **Binance UID: 1049392123**.
- **Transferencia directa en Criptoactivos Estables a Billetera Binance:** USDT o USDC a través de redes seguras de baja latencia (Polygon MATIC, BNB Smart Chain BEP-20, o TRON TRC-20).
- **Pasarela de Tarjeta Corporativa con Liquidación Cripto:** Enlace de pago para tarjetas Visa/Mastercard con acreditación directa en USDT a la cuenta del PROVEEDOR en Binance.
- **Transferencia Internacional (USD/EUR):** Acreditación vía cuenta receptora con liquidación vinculada a Binance.

---

### QUINTA. CLÁUSULA DE REVERSIÓN TOTAL DE RIESGO (GARANTÍA A 14 DÍAS)
Ambas partes convienen una garantía expresa de funcionamiento y satisfacción:

> **Compromiso de Desempeño:**  
> Si durante el período de prueba de **catorce (14) días continuos** posteriores a la puesta en marcha, el sistema implementado no lograra procesar, calificar y enrutar el 100% de los leads válidos que ingresen por el formulario en un tiempo inferior a sesenta (60) segundos debido a defectos atribuibles a la arquitectura programada por el PROVEEDOR, y dicho inconveniente no fuera subsanado en un lapso de 48 horas tras ser reportado:
>
> 1. El CLIENTE queda **completamente eximido** de realizar el pago del segundo hito ($375.00 USD).
> 2. El PROVEEDOR realizará el **reembolso íntegro e inmediato del 100% del depósito inicial ($375.00 USD)** dentro de las 72 horas hábiles siguientes a la solicitud formal.
> 3. El CLIENTE conservará el acceso a las hojas de cálculo y automatizaciones ya instaladas.

*Exclusión de Garantía:* No aplican para la garantía caídas generales de servicio ajenas a las partes (interrupciones globales de Google Cloud, Meta o caídas de servidor de hosting propio del cliente) ni manipulaciones no autorizadas del código por parte de personal ajeno al PROVEEDOR.

---

### SEXTA. CONFIDENCIALIDAD Y PROTECCIÓN DE DATOS (NDA)
1. El PROVEEDOR se obliga a mantener bajo la más estricta reserva toda la información técnica, comercial, bases de datos de prospectos, métricas y contraseñas a las que tenga acceso durante la ejecución de los servicios.
2. En ningún momento el PROVEEDOR almacenará, transferirá o comercializará datos de los prospectos (leads) del CLIENTE. Todos los datos transitan exclusivamente por la infraestructura y cuentas de propiedad del CLIENTE.

### SÉPTIMA. PROPIEDAD INTELECTUAL
Una vez liquidado el Hito 2 del contrato, el CLIENTE adquiere la titularidad total e irrestricta de uso de las hojas de cálculo, escenarios, scripts y configuraciones implementadas en su cuenta, otorgándole el derecho a utilizarlas, modificarlas o ampliarlas libremente sin pago de regalías adicionales al PROVEEDOR.

### OCTAVA. INDEPENDENCIA CONTRACTUAL
El presente acuerdo es de naturaleza estrictamente mercantil y no constituye relación laboral, societaria o de subordinación alguna entre las partes ni entre sus colaboradores.

---

### ACEPTACIÓN Y FIRMAS

En prueba de conformidad y aceptación de todas y cada una de las cláusulas anteriores, las partes firman el presente documento en formato digital:

**POR EL PROVEEDOR:**  
Firma: ___________________________________  
Nombre: [Nombre del Consultor]  
Fecha: [DD/MM/AAAA]  

**POR EL CLIENTE:**  
Firma: ___________________________________  
Nombre: [Nombre del Representante]  
Empresa: [Nombre de la Agencia Cliente]  
Fecha: [DD/MM/AAAA]  
